package com.rolebook.dao;

public class UserDao {
	//Déclaration d'une variable pour la connection
	private Connection connect;
	//Déclaration d'une variable pour stocker la requête SQL
	private String query;
	private ResultSet 
}
