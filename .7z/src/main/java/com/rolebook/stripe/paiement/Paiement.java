package com.rolebook.stripe.paiement;

public class Paiement {

	public static void main(String[] args) {

	}

}
